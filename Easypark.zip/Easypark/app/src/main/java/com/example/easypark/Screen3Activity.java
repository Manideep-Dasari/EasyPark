package com.example.easypark;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Screen3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen3); // Replace with your layout file name
    }
}
